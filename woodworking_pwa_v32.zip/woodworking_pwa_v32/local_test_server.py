import http.server, socketserver
PORT = 8080
print(f"Open http://localhost:{PORT}/index.html")
with socketserver.TCPServer(("", PORT), http.server.SimpleHTTPRequestHandler) as httpd:
    httpd.serve_forever()
